$(function(){$("#selectimg").click(function(){document.getElementById("form1").submit()});$("#txtFile").change(function(){$("#fake_1").val($(this).val())})});
