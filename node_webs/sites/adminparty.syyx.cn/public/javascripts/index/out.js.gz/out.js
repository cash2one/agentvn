$.post("/login/check",function(a){0==a.ok&&(document.location="/login.html")},"json");
